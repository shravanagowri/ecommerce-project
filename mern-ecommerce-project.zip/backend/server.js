import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';

const app = express();
app.use(express.json());
app.use(cors());

app.get('/', (req, res) => {
  res.send('API Running');
});

mongoose.connect('mongodb://127.0.0.1:27017/ecommerce')
.then(()=>console.log('MongoDB Connected'))
.catch(err=>console.log(err));

app.listen(5000, ()=>console.log('Server running on port 5000'));
